import { writeFile } from 'fs';

writeFile('welcome.txt', 'Hello Node', (err) => {
    if (err) throw err;
    console.log('Fichier créé : welcome.txt');
});
