const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'votre_email@gmail.com',
        pass: 'votre_mot_de_passe'
    }
});

const mailOptions = {
    from: 'votre_email@gmail.com',
    to: 'destinataire_email@gmail.com',
    subject: 'Test Node.js Email',
    text: 'Bonjour, ceci est un test d\'email depuis Node.js.'
};
transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
        console.log(error);
    } else {
        console.log('E-mail envoyé : ' + info.response);
    }
});


