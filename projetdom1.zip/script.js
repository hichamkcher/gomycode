document.addEventListener('DOMContentLoaded', () => {
  const articles = document.querySelectorAll('.article');
  const totalElement = document.getElementById('total');
  const addArticles = document.querySelector('.btn-article')

  articles.forEach(article => {
      const btnPlus = article.querySelector('.btn-plus');
      const btnMinus = article.querySelector('.btn-minus');
      const btnSupprimer = article.querySelector('.btn-supprimer');
      const btnHeart = article.querySelector('.btn-heart');
      const quantiteElement = article.querySelector('.quantite');
      const prixUnitaire = parseFloat(article.getAttribute('data-prix'));
      btnPlus.addEventListener('click', () => {
          let quantite = parseInt(quantiteElement.textContent);
          quantite++;
          quantiteElement.textContent = quantite;
          updateTotal();
      });

      btnMinus.addEventListener('click', () => {
          let quantite = parseInt(quantiteElement.textContent);
          if (quantite > 1) {
              quantite--;
              quantiteElement.textContent = quantite;
              updateTotal();
          }
      });

      btnSupprimer.addEventListener('click', () => {
          article.remove();
          updateTotal();
      });

      btnHeart.addEventListener('click', () => {
          btnHeart.classList.toggle('liked');
      });
  });

  function updateTotal() {
      let total = 0;
      articles.forEach(article => {
          const quantite = parseInt(article.querySelector('.quantite').textContent);
          const prixUnitaire = parseFloat(article.getAttribute('data-prix'));
          total += quantite * prixUnitaire;
      });
      totalElement.textContent = total.toFixed(2);
  }
});